package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import bean.User;
import dao.DBUtils;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public LoginServlet() {
        super();
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	request.setCharacterEncoding("utf-8");
	// ���տͻ�����Ϣ
	User user = new User(request.getParameter("username"),request.getParameter("password"));
        // ��֤����
        System.out.println("Android�˽������ݳɹ���!!"+user);
//        Map<String, String> map = DBUtils.login(user);
        List<User> map = (List<User>) DBUtils.login(user);
        PrintWriter out = null;
        if(map!=null) {
            System.out.println("���ݲ�ѯ�ɹ���!!");
            // ������Ϣ���ͻ���
            response.setCharacterEncoding("UTF-8");
            response.setContentType("text/html");
            out = response.getWriter();
            Gson gson=new Gson();
            String jString=gson.toJson(map);
//            System.out.println(jString);
            out.print(jString);   //һ�㷵��json���ݣ�����Ӽ�
            out.flush();
            out.close();
        }
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
    }
}
