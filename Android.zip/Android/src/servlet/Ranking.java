package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import bean.Student;
import dao.DBUtils;

/**
 * Servlet implementation class Ranking
 */
@WebServlet("/Ranking")
public class Ranking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ranking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String signal=request.getParameter("signal");
		String myclass=request.getParameter("myclass");
		List<Student> map = null;
		if(signal.equals("1")) {
			map = (List<Student>) DBUtils.Ranking_1(myclass);
		}else if(signal.equals("2")){
			map = (List<Student>) DBUtils.Ranking_2(myclass);
		}else if(signal.equals("3")){
			map = (List<Student>) DBUtils.Ranking_3(myclass);
		}
		 PrintWriter out = null;
	        if(map!=null) {
	            System.out.println("���ݲ�ѯ�ɹ���!!");
	            // ������Ϣ���ͻ���
	            response.setCharacterEncoding("UTF-8");
	            response.setContentType("text/html");
	            out = response.getWriter();
	            Gson gson=new Gson();
	            String jString=gson.toJson(map);
	            System.out.println(jString);
	            out.print(jString);   //һ�㷵��json���ݣ�����Ӽ�
	            out.flush();
	            out.close();
	        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
