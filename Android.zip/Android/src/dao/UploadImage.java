package dao;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.codec.binary.Base64;



public class UploadImage {

    public static void convertStringtoImage(String encodedImageStr, String fileName) {

        try {
            // Base64����ͼƬ
            byte[] imageByteArray = Base64.decodeBase64(encodedImageStr);

            //
            FileOutputStream imageOutFile = new FileOutputStream("D:/eclipse/project/Android/WebContent/uploads/" + fileName+".jpg");
            imageOutFile.write(imageByteArray);

            imageOutFile.close();

            System.out.println("Image Successfully Stored");
        } catch (FileNotFoundException fnfe) {
            System.out.println("Image Path not found" + fnfe);
        } catch (IOException ioe) {
            System.out.println("Exception while converting the Image " + ioe);
        }
    }
}
