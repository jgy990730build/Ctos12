package dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import bean.Student;
import bean.User;

public class DBUtils {
    private static String driver = "com.mysql.jdbc.Driver";//MySQL ����
    private static String url = "jdbc:mysql://172.16.156.35:3306/test";//MYSQL���ݿ�����Url
    private static String user = "root";//�û���
    private static String password = "123456";//����
 
    private static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName(driver); //
            conn = (Connection) DriverManager.getConnection(url,user, password);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return conn;
    }
//    public static Map login(User user) {
//        HashMap<String, String> map = new HashMap<>();
//        Connection conn = getConnection();
//        try {
//            Statement st = (Statement) conn.createStatement();
//            String sql= "select * from user1 where username ='" + user.getUsername()
//                    + "' and pwd ='" + user.getPassword() + "'";
//            ResultSet res = st.executeQuery(sql);
//            if (res == null) {
//                return null;
//            } else {
//                int cnt = res.getMetaData().getColumnCount();
//                res.next();
//                for (int i = 1; i <= cnt; ++i) {
//                    String field = res.getMetaData().getColumnName(i);
//                    map.put(field, res.getString(field));
//                }
//                conn.close();
//                st.close();
//                res.close();
//                return map;
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            return null;
//        }
//    }
    public static List<User> login(User user){
    	List<User> users = new ArrayList<>();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from user1 where username ='" + user.getUsername()
                   + "' and pwd ='" + user.getPassword() + "'";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        	   System.out.println(res.getString(1));
        	   System.out.println(res.getString(2));
               User user1=new User();
               user1.setUsername(res.getString(1));
               user1.setPassword(res.getString(2));
               user1.setRole(res.getString(3));
               users.add(user1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return users;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static String query_class(int id){
    	String classid="1";
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select student_class from teacher where id ='" + id
                   + "'";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
//        		   System.out.println(res.getString(1));
        		   classid=res.getString(1);    		  
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return classid;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> query(String classid){
    	List<Student> students = new ArrayList<>();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where student_class ='" + classid
                   + "' and admin_flag = 1";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setId(res.getInt(1));
        		  students1.setStudent_name(res.getString(2));
        		  students1.setClass1(res.getString(4));
        		  students1.setComprehensive_assessment(res.getInt(6));
        		  students1.setAdmin_flag(res.getInt(12));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> Ranking_1(String classid){
    	List<Student> students = new ArrayList<>();
    	System.out.println(classid);
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where student_class ='" + classid
                   + "' and admin_flag = 1 ORDER BY comprehensive_assessment DESC";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setId(res.getInt(1));
//        		  System.out.println(res.getInt(1));
        		  students1.setStudent_name(res.getString(2));
        		  students1.setComprehensive_assessment(res.getInt(6));
        		  students1.setAdmin_flag(res.getInt(12));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> Ranking_2(String classid){
    	List<Student> students = new ArrayList<>();
//    	System.out.println(classid);
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where student_class ='" + classid
                   + "' and admin_flag = 1 ORDER BY comprehensive_assessment asc";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setId(res.getInt(1));
        		  System.out.println(res.getInt(1));
        		  students1.setStudent_name(res.getString(2));
        		  students1.setComprehensive_assessment(res.getInt(6));
        		  students1.setAdmin_flag(res.getInt(12));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> Ranking_3(String classid){
    	List<Student> students = new ArrayList<>();
//    	System.out.println(classid);
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where student_class ='" + classid
                   + "' and admin_flag = 1 ORDER BY id DESC";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setId(res.getInt(1));
        		  System.out.println(res.getInt(1));
        		  students1.setStudent_name(res.getString(2));
        		  students1.setComprehensive_assessment(res.getInt(6));
        		  students1.setAdmin_flag(res.getInt(12));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> CheckStudentRecord(String classid){
    	List<Student> students = new ArrayList<>();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where student_class ='" + classid
                   + "' and teacher_flag = 0";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setId(res.getInt(1));
        		  students1.setStudent_name(res.getString(2));
        		  students1.setCompetition_add(res.getString(7));
        		  students1.setActivity_add(res.getString(8));
        		  students1.setCadres_add(res.getString(9));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> QueryStudentRecord(String classid,String key){
    	List<Student> students = new ArrayList<>();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select student_name,final_grades from student where student_class = '" + classid
                   + "' and student_name LIKE  '%"+key+"%'";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setStudent_name(res.getString(1));
        		  students1.setFinal_grades(res.getInt(2));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static List<Student> QueryStudentRecord_id(String classid,int key){
    	List<Student> students = new ArrayList<>();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select student_name,final_grades from student where student_class = '" + classid
                   + "' and id = "+key;
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  
        		  students1.setStudent_name(res.getString(1));
        		  students1.setFinal_grades(res.getInt(2));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static Student CheckOneStudentRecord(int student_id){
    	Student student = new Student();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where id ='" + student_id
                   + "' ";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  student.setId(res.getInt(1));
        		  student.setStudent_name(res.getString(2));
        		  student.setClass1(res.getString(4));
        		  student.setCompetition_add(res.getString(7));
        		  student.setActivity_add(res.getString(8));
        		  student.setCadres_add(res.getString(9));
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return student;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static Boolean update(int student_id){
    	Student student = new Student();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "update student set teacher_flag = 1 where id ='" + student_id
                   + "' ";
           int res = st.executeUpdate(sql);
           if (res != 0) {
        	   System.out.println("�����ɹ�,��Ӱ��" + res + "��");
        	   conn.close();
               st.close();
        	   return true;   	   
           }else {
        	   conn.close();
               st.close();
        	   return false; 
           }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static int update_studentadd(int student_id,String sadd1,String sadd2,String sadd3){
    	Student student = new Student();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "update student set competition_add = "+sadd1+", activity_add = "+sadd2+", cadres_add="+sadd3
        		   +" where id ='" + student_id
                   + "' ";
           int res = st.executeUpdate(sql);
           if (res != 0) {
        	   System.out.println("�����ɹ�,��Ӱ��" + res + "��");
        	   conn.close();
               st.close();
        	   return 1;   	   
           }else {
        	   conn.close();
               st.close();
        	   return 0; 
           }
       } catch (Exception e) {
           e.printStackTrace();
           return 0;
       }
    }
    public static List<Student> My(int id){
    	List<Student> students = new ArrayList<>();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "select * from student where id ='" + id
                   + "'";
           ResultSet res = st.executeQuery(sql);
           if (res == null) {
               return null;
           } else {
        	   while(res.next()) {
        		  Student students1=new Student();
        		  students1.setFinal_grades(res.getInt(5));
        		  students1.setComprehensive_assessment(res.getInt(6));
        		  students1.setAdmin_flag(res.getInt(12));
        		  students.add(students1);
        	   }
        	   conn.close();
               st.close();
               res.close();
        	   return students;   	   
    	 }
       } catch (Exception e) {
           e.printStackTrace();
           return null;
       }
    }
    public static int Done(String student_id,String ca){
    	Student student = new Student();
    	 Connection conn = getConnection();
    	 try {
           Statement st = (Statement) conn.createStatement();
           String sql= "update student set comprehensive_assessment = "+ca+",admin_flag = 1 where id ='" + student_id
                   + "' ";
           int res = st.executeUpdate(sql);
           if (res != 0) {
        	   System.out.println("�����ɹ�,��Ӱ��" + res + "��");
        	   conn.close();
               st.close();
        	   return 1;   	   
           }else {
        	   conn.close();
               st.close();
        	   return 0; 
           }
       } catch (Exception e) {
           e.printStackTrace();
           return 0;
       }
    }
}
