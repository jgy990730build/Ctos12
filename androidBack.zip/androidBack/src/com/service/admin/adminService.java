package com.service.admin;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.admin;

public interface adminService {
	public String login(admin admin, Model model, HttpSession session);
}
