package com.service.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.adminStudentDao;
import com.po.student;

@Service("studentService")
@Transactional
public class studentServiceImpl implements studentService {
	@Autowired
	private adminStudentDao adminStudentDao;
	@Override
	public List<student> getStudentList() {
		List<student> allstudent = adminStudentDao.selectStudent();
		return allstudent;
	}

}
