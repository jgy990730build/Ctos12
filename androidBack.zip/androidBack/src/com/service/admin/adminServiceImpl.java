package com.service.admin;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import com.po.admin;
@Service("adminService")
@Transactional
public class adminServiceImpl implements adminService{
	@Autowired
	private com.dao.adminDao adminDao;
	@Override
	public String login(admin admin, Model model, HttpSession session) {
		if(adminDao.login(admin) != null && adminDao.login(admin).size() > 0) {
			session.setAttribute("admin", admin);
			return "admin/main";
		}
		model.addAttribute("msg", "�û������������");
		return "admin/login";
	}

}
