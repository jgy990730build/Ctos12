package com.service.admin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.dao.adminStudentDao;
import com.po.student;
import com.util.MyUtil;
@Service("adminStudentService")
@Transactional
public class adminStudentServiceImpl implements adminStudentService{
	@Autowired
	private adminStudentDao adminStudentDao;
	/**
	 * ���ӻ����
	 */
	@Override
	public String addOrUpdateStudentById(student student, HttpServletRequest request, String updateAct) {
		//�޸�
		if("update".equals(updateAct)){//updateAct������act��������Ϊʹ����ת��
			//�޸ĵ����ݿ�
	       if(adminStudentDao.updateStudentById(student) > 0){
	        	return "forward:/adminStudent/selectStudent?act=updateSelect";
	        }else{
	        	return "/adminStudent/updateAstudent";
	       }
		}else{//��
			//���浽���ݿ�
			if(adminStudentDao.addStudent(student) > 0){
				//ת������ѯ��controller
				return "forward:/adminStudent/selectStudent";
			}else{
				return "card/addCard";
			}
		}
	}
	//��ѯ
	@Override
	public String selectStudent(Model model, Integer pageCur, String act) {
		List<student> allstudent = adminStudentDao.selectStudent();
		int temp = allstudent.size();
		model.addAttribute("totalCount", temp);
		int totalPage = 0;
		if (temp == 0) {
			totalPage = 0;//��ҳ��
		} else {
			//���ش��ڻ��ߵ���ָ������ʽ����С����
			totalPage = (int) Math.ceil((double) temp / 10);
		}
		if (pageCur == null) {
			pageCur = 1;
		}
		if ((pageCur - 1) * 10 > temp) {
			pageCur = pageCur - 1;
		}
		//��ҳ��ѯ
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startIndex", (pageCur - 1) * 10);//��ʼλ��
		map.put("perPageSize", 10);//ÿҳ10��
//		allstudent = adminStudentDao.selectAllStudentByPage(map);
		model.addAttribute("allstudent", allstudent);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("pageCur", pageCur);
		//ɾ����ѯ
		if("deleteSelect".equals(act)){
			return "admin/deleteSelectStudent";
		}
		else if ("reviewSelect".equals(act)) {
			return "admin/review";
		}
		//�޸Ĳ�ѯ
		else if("updateSelect".equals(act)){
			return "admin/updateSelectStudent";
		}else{
			return "admin/selectStudent";
		}
	}
	
	/**
	 * ��ѯһ��
	 */
	@Override
	public String selectAStudent(Model model, Integer id, String act) {
		student student = adminStudentDao.selectStudentById(id);
		model.addAttribute("student", student);
		//�޸�ҳ��
		if("updateAstudent".equals(act)){
			return "admin/updateAstudent";
		}
		//����ҳ��
		return "admin/updateSelectStudent";
	}
	/**
	 * ���һ��
	 */
	public String reviewStudent(Integer id, Model model){
		adminStudentDao.reviewStudent(id);
		model.addAttribute("msg", "��˳ɹ���");
		return "forward:/adminStudent/selectStudent?act=reviewSelect";
	}
	/**
	 * ��˶��ѧ��
	 */
	@Override
	public String reviewStudents(Integer[] ids, Model model) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < ids.length; i++) {
			list.add(ids[i]);
		}
		adminStudentDao.reviewStudents(list);
		model.addAttribute("msg", "�ɹ����ѧ����");
		return "forward:/adminStudent/selectStudent?act=reviewSelect";
	}
	/**
	 * ɾ��һ��
	 */
	@Override
	public String deleteAStudent(Integer id, Model model) {
		adminStudentDao.deleteAStudent(id);
		model.addAttribute("msg", "�ɹ�ɾ����");
		return "forward:/adminStudent/selectStudent?act=deleteSelect";
	}
	/**
	 * ɾ�������Ʒ
	 */
	@Override
	public String deleteStudent(Integer[] ids, Model model) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < ids.length; i++) {
			list.add(ids[i]);
		}
		adminStudentDao.deleteStudent(list);
		model.addAttribute("msg", "�ɹ�ɾ����Ʒ��");
		return "forward:/adminStudent/selectStudent?act=deleteSelect";
	}
}
