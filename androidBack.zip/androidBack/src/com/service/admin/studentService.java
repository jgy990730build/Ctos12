package com.service.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.admin;
import com.po.student;

public interface studentService {
	public List<student> getStudentList();
}
