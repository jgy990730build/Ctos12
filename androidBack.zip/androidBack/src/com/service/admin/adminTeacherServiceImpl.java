package com.service.admin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.dao.adminTeacherDao;
import com.po.teacher;
import com.util.MyUtil;
@Service("adminTeacherService")
@Transactional
public class adminTeacherServiceImpl implements adminTeacherService{
	@Autowired
	private adminTeacherDao adminTeacherDao;
	/**
	 * ���ӻ����
	 */
	@Override
	public String addOrUpdateTeacherById(teacher teacher, HttpServletRequest request, String updateAct) {
		//�޸�
		if("update".equals(updateAct)){//updateAct������act��������Ϊʹ����ת��
			//�޸ĵ����ݿ�
	       if(adminTeacherDao.updateTeacherById(teacher) > 0){
	        	return "forward:/adminTeacher/selectTeacher?act=updateSelect";
	        }else{
	        	return "/adminTeacher/updateAteacher";
	       }
		}else{//��
			//���浽���ݿ�
			if(adminTeacherDao.addTeacher(teacher) > 0){
				//ת������ѯ��controller
				return "forward:/adminTeacher/selectTeacher";
			}else{
				return "card/addCard";
			}
		}
	}
	//��ѯ
	@Override
	public String selectTeacher(Model model, Integer pageCur, String act) {
		List<teacher> allteacher = adminTeacherDao.selectTeacher();
		int temp = allteacher.size();
		model.addAttribute("totalCount", temp);
		int totalPage = 0;
		if (temp == 0) {
			totalPage = 0;//��ҳ��
		} else {
			//���ش��ڻ��ߵ���ָ������ʽ����С����
			totalPage = (int) Math.ceil((double) temp / 10);
		}
		if (pageCur == null) {
			pageCur = 1;
		}
		if ((pageCur - 1) * 10 > temp) {
			pageCur = pageCur - 1;
		}
		//��ҳ��ѯ
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startIndex", (pageCur - 1) * 10);//��ʼλ��
		map.put("perPageSize", 10);//ÿҳ10��
//		allteacher = adminTeacherDao.selectAllTeacherByPage(map);
		model.addAttribute("allteacher", allteacher);
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("pageCur", pageCur);
		//ɾ����ѯ
		if("deleteSelect".equals(act)){
			return "admin/deleteSelectTeacher";
		}
		//�޸Ĳ�ѯ
		else if("updateSelect".equals(act)){
			return "admin/updateSelectTeacher";
		}else{
			return "admin/selectTeacher";
		}
	}
	
	/**
	 * ��ѯһ��
	 */
	@Override
	public String selectATeacher(Model model, Integer id, String act) {
		teacher teacher = adminTeacherDao.selectTeacherById(id);
		model.addAttribute("teacher", teacher);
		//�޸�ҳ��
		if("updateAteacher".equals(act)){
			return "admin/updateAteacher";
		}
		//����ҳ��
		return "admin/updateSelectTeacher";
	}
	/**
	 * ɾ��һ��
	 */
	@Override
	public String deleteATeacher(Integer id, Model model) {
		adminTeacherDao.deleteATeacher(id);
		model.addAttribute("msg", "�ɹ�ɾ����");
		return "forward:/adminTeacher/selectTeacher?act=deleteSelect";
	}
	/**
	 * ɾ�������Ʒ
	 */
	@Override
	public String deleteTeacher(Integer[] ids, Model model) {
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i < ids.length; i++) {
			list.add(ids[i]);
		}
		adminTeacherDao.deleteTeacher(list);
		model.addAttribute("msg", "�ɹ�ɾ����Ʒ��");
		return "forward:/adminTeacher/selectTeacher?act=deleteSelect";
	}
}
