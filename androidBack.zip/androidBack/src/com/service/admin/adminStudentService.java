package com.service.admin;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.po.student;
public interface adminStudentService {
	public String selectStudent(Model model, Integer pageCur, String act);
	public String selectAStudent(Model model, Integer id, String act);
	public String deleteAStudent(Integer id, Model model);
	public String deleteStudent(Integer ids[], Model model);
	public String addOrUpdateStudentById(student student, HttpServletRequest request, String updateAct);
	public String reviewStudent(Integer id, Model model);
	public String reviewStudents(Integer ids[], Model model);
}
