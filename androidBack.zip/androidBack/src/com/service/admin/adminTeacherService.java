package com.service.admin;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import com.po.teacher;
public interface adminTeacherService {
	public String selectTeacher(Model model, Integer pageCur, String act);
	public String selectATeacher(Model model, Integer id, String act);
	public String deleteATeacher(Integer id, Model model);
	public String deleteTeacher(Integer ids[], Model model);
	public String addOrUpdateTeacherById(teacher teacher, HttpServletRequest request, String updateAct);
}
