package com.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpSession;
import com.po.student;
import com.po.teacher;
public class MyUtil {
	/**
	 * ���ʱ���ַ���
	 */
	public static String getStringID(){
		String id=null;
		Date date=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmssSSS"); 
		id=sdf.format(date);
		return id;
	}
	/**
	 * ����û�ID
	 */
	public static Integer getTeacherId(HttpSession session) {
		teacher teacher = (teacher)session.getAttribute("teacher");
		return teacher.getId();
	}
	public static Integer getStudentId(HttpSession session) {
		student student = (student)session.getAttribute("student");
		return student.getId();
	}
}
