package com.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.teacher;
@Repository("adminTeacherDao")
@Mapper
public interface adminTeacherDao {
	public List<teacher> selectTeacher();
//	public List<teacher> selectAllTeacherByPage(Map<String, Object> map);
	public int addTeacher(teacher teacher);
	public int deleteTeacher(List<Integer> ids);
	public int deleteATeacher(Integer id);
	public int updateTeacherById(teacher teacher);
	public teacher selectTeacherById(Integer id);
}
