package com.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.student;
@Repository("adminStudentDao")
@Mapper
public interface adminStudentDao {
	public List<student> selectStudent();
//	public List<student> selectAllStudentByPage(Map<String, Object> map);
	public int addStudent(student student);
	public int deleteStudent(List<Integer> ids);
	public int deleteAStudent(Integer id);
	public int updateStudentById(student student);
	public student selectStudentById(Integer id);
	public int reviewStudent(Integer id);
	public int reviewStudents(List<Integer> ids);
}
