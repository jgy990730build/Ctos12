package com.exception;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import com.po.admin;
public class MyExceptionHandler implements HandlerExceptionResolver {
	@Override
	public ModelAndView resolveException(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2,
			Exception arg3) {
	   	Map<String, Object> model = new HashMap<String, Object>();  
        model.put("ex", arg3); 
        // ���ݲ�ͬ����ת��ͬҳ��  
       if(arg3 instanceof AdminLoginNoException){
        	//��¼ҳ����Ҫauser����
        	arg0.setAttribute("admin", new admin());
        	arg0.setAttribute("msg", "û�е�¼�����¼��");
        	return new ModelAndView("/admin/login", model);
        } else{  
        	return new ModelAndView("/error/error", model);  
        }  
	}
}
