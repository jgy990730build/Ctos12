package com.exception;
public class UserLoginNoException extends Exception{
	private static final long serialVersionUID = 1L;
	public UserLoginNoException(String message){
		super(message);
	}
}
