package com.controller.admin;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.student;
import com.service.admin.adminStudentService;
@Controller
@RequestMapping("/adminStudent")
public class adminStudentController extends BaseController{
	@Autowired
	private adminStudentService adminStudentService;
	@RequestMapping("/selectStudent")
	public String selectStudent(Model model, Integer pageCur, String act) {
		return adminStudentService.selectStudent(model, pageCur, act);
	}
	/**
	 * addҳ���ʼ��
	 */
	@RequestMapping("/toAddStudent")
	public String toAddStudent(Model model){
		model.addAttribute("student", new student());
		return "admin/addStudent";
	}
	/**
	 * �������޸�
	 */
	@RequestMapping("/addStudent")
	public String addStudent(@ModelAttribute student student, HttpServletRequest request, String updateAct){
		return adminStudentService.addOrUpdateStudentById(student, request, updateAct);
	}
	/**
	 * ���һ��
	 */
	@RequestMapping("/reviewStudent")
	public String reviewStudent(Integer id, Model model) {
		return adminStudentService.reviewStudent(id, model);
	}
	/**
	 * ɾ�����ѧ��
	 */
	@RequestMapping("/reviewStudents")
	public String reviewStudents(Integer ids[], Model model) {
		return adminStudentService.reviewStudents(ids, model);
	}
	/**
	 * ��ѯһ����Ƭ
	 */
	@RequestMapping("/selectAStudent")
	public String selectAStudent(Model model, Integer id, String act){
		return adminStudentService.selectAStudent(model, id, act);
	}
	
	/**
	 * ɾ������ѧ��
	 */
	@RequestMapping("/deleteAStudent")
	public String deleteAStudent(Integer id, Model model) {
		return adminStudentService.deleteAStudent(id, model);
	}
	/**
	 * ɾ�����ѧ��
	 */
	@RequestMapping("/deleteStudent")
	public String deleteStudent(Integer ids[], Model model) {
		return adminStudentService.deleteStudent(ids, model);
	}
}
