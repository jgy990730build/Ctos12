package com.controller.admin;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.teacher;
import com.service.admin.adminTeacherService;
@Controller
@RequestMapping("/adminTeacher")
public class adminTeacherController extends BaseController{
	@Autowired
	private adminTeacherService adminTeacherService;
	@RequestMapping("/selectTeacher")
	public String selectTeacher(Model model, Integer pageCur, String act) {
		return adminTeacherService.selectTeacher(model, pageCur, act);
	}
	/**
	 * addҳ���ʼ��
	 */
	@RequestMapping("/toAddTeacher")
	public String toAddTeacher(Model model){
		model.addAttribute("teacher", new teacher());
		return "admin/addTeacher";
	}
	/**
	 * �������޸�
	 */
	@RequestMapping("/addTeacher")
	public String addTeacher(@ModelAttribute teacher teacher, HttpServletRequest request, String updateAct){
		return adminTeacherService.addOrUpdateTeacherById(teacher, request, updateAct);
	}
	/**
	 * ��ѯһ����Ƭ
	 */
	@RequestMapping("/selectATeacher")
	public String selectATeacher(Model model, Integer id, String act){
		return adminTeacherService.selectATeacher(model, id, act);
	}
	
	/**
	 * ɾ��������Ʒ
	 */
	@RequestMapping("/deleteATeacher")
	public String deleteATeacher(Integer id, Model model) {
		return adminTeacherService.deleteATeacher(id, model);
	}
	/**
	 * ɾ�������Ʒ
	 */
	@RequestMapping("/deleteTeacher")
	public String deleteGoods(Integer ids[], Model model) {
		return adminTeacherService.deleteTeacher(ids, model);
	}
}
