package com.controller.admin;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.student;
import com.service.admin.studentService;

@Controller
public class excelController {
	private studentService studentService;
//	����
	@RequestMapping("exportexcel")
	public void exportexcel(HttpServletResponse response) {
		OutputStream oStream = null;
		
		try {
//			����������
			HSSFWorkbook wb = new HSSFWorkbook();
//			����sheet
			HSSFSheet sheet = wb.createSheet("�б�");
//			������ͷ
			HSSFRow row = sheet.createRow(0);
			//������Ԫ��
			HSSFCell cell = row.createCell(0);
			cell.setCellValue("ѧ��");
			HSSFCell cell1 = row.createCell(1);
			cell1.setCellValue("ѧ������");
			HSSFCell cell2 = row.createCell(2);
			cell2.setCellValue("����");
			HSSFCell cell3 = row.createCell(3);
			cell3.setCellValue("��ѧ�༶");
			HSSFCell cell4 = row.createCell(4);
			cell4.setCellValue("��ĩ�ɼ�");
			HSSFCell cell5 = row.createCell(5);
			cell5.setCellValue("�ۺϲ�������");
			HSSFCell cell6 = row.createCell(6);
			cell6.setCellValue("�����ӷ�");
			HSSFCell cell7 = row.createCell(7);
			cell7.setCellValue("��ӷ�");
			HSSFCell cell8 = row.createCell(8);
			cell8.setCellValue("ѧ���ɲ��ӷ�");
			HSSFCell cell9 = row.createCell(9);
			cell9.setCellValue("ͼƬ֤��");
			HSSFCell cell10 = row.createCell(10);
			cell10.setCellValue("��ʦ���");
			HSSFCell cell11 = row.createCell(11);
			cell11.setCellValue("����Ա���");
			student student = new student();
			List<student> list = studentService.getStudentList();
			System.out.println(list);
			for(int i=0;i<list.size();i++){
				student student1 = list.get(i);
				//������ͷ
				HSSFRow lrow = sheet.createRow(i+1);
				//������Ԫ��
				HSSFCell lcell = lrow.createCell(0);
				lcell.setCellValue(student1.getId());
				HSSFCell lcell1 = lrow.createCell(1);
				lcell1.setCellValue(student1.getStudent_name());
				HSSFCell lcell2 = lrow.createCell(2);
				lcell2.setCellValue(student1.getPwd());
				HSSFCell lcell3 = lrow.createCell(3);
				lcell3.setCellValue(student1.getStudent_class());
				HSSFCell lcell4 = lrow.createCell(4);
				lcell4.setCellValue(student1.getFinal_grades());
				HSSFCell lcell5 = lrow.createCell(5);
				lcell5.setCellValue(student1.getComprehensive_assessment());
				HSSFCell lcell6 = lrow.createCell(6);
				lcell6.setCellValue(student1.getCompetition_add());
				HSSFCell lcell7 = lrow.createCell(7);
				lcell7.setCellValue(student1.getActivity_add());
				HSSFCell lcell8 = lrow.createCell(8);
				lcell8.setCellValue(student1.getCadres_add());
				HSSFCell lcell9 = lrow.createCell(9);
				lcell9.setCellValue(student1.getPicture_prove());
				HSSFCell lcell10 = lrow.createCell(10);
				lcell10.setCellValue(student1.getTeacher_flag());
				HSSFCell lcell11 = lrow.createCell(11);
				lcell11.setCellValue(student1.getAdmin_flag());
			}
			//����response��ȡ�����
			response.setContentType("application/force-download"); // ������������
			response.setHeader("Content-Disposition","attachment;filename=sxlb.xls"); // �����ļ�������
			oStream = response.getOutputStream(); // �����
			//�ѹ�����д�뵽�����
			wb.write(oStream);
			
		} catch (Exception e) {
			// TODO: handle exception
			try {
				oStream.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
	}
}
