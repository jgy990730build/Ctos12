package com.po;

public class student {
	private Integer id;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Integer getFinal_grades() {
		return final_grades;
	}
	public void setFinal_grades(Integer final_grades) {
		this.final_grades = final_grades;
	}
	public Integer getComprehensive_assessment() {
		return comprehensive_assessment;
	}
	public void setComprehensive_assessment(Integer comprehensive_assessment) {
		this.comprehensive_assessment = comprehensive_assessment;
	}
	public String getCompetition_add() {
		return competition_add;
	}
	public void setCompetition_add(String competition_add) {
		this.competition_add = competition_add;
	}
	public String getActivity_add() {
		return activity_add;
	}
	public void setActivity_add(String activity_add) {
		this.activity_add = activity_add;
	}
	public String getCadres_add() {
		return cadres_add;
	}
	public void setCadres_add(String cadres_add) {
		this.cadres_add = cadres_add;
	}
	public String getPicture_prove() {
		return picture_prove;
	}
	public void setPicture_prove(String picture_prove) {
		this.picture_prove = picture_prove;
	}
	public Integer getTeacher_flag() {
		return teacher_flag;
	}
	public void setTeacher_flag(Integer teacher_flag) {
		this.teacher_flag = teacher_flag;
	}
	public Integer getAdmin_flag() {
		return admin_flag;
	}
	public void setAdmin_flag(Integer admin_flag) {
		this.admin_flag = admin_flag;
	}
	private String student_name;
	private String pwd;
	private String student_class;
	public String getStudent_class() {
		return student_class;
	}
	public void setStudent_class(String student_class) {
		this.student_class = student_class;
	}
	private Integer final_grades;
	private Integer comprehensive_assessment;
	private String competition_add;
	private String activity_add;
	private String cadres_add;
	private String picture_prove;
	private Integer teacher_flag;
	private Integer admin_flag;
	
}
